<?php
include("Database.php");

$database = new Database();
$conn = $database->connect();

$registration_id = $_GET['registration_id'];

$sql = "DELETE FROM registrations
        WHERE registration_id = '$registration_id'";

if(mysqli_query($conn, $sql))
{
    echo "<h2>Course Dropped Successfully!</h2>";
}
else
{
    echo "Error dropping course.";
}
?>

<br><br>

<a href="my_schedule.php">Back to My Schedule</a>