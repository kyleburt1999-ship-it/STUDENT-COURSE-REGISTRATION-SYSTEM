<?php
session_start();
include("Database.php");

$database = new Database();
$conn = $database->connect();

$user_id = 1;

$course_id = $_GET['course_id'];

$sql = "INSERT INTO registrations (user_id, course_id)
VALUES ('$user_id','$course_id')";

if(mysqli_query($conn,$sql))
{
    echo "<h2>Course Registered Successfully!</h2>";
}
else
{
    echo "Error";
}
?>

<br><br>

<a href="register_course.php">Register Another Course</a>

<br><br>

<a href="my_schedule.php">View My Schedule</a>