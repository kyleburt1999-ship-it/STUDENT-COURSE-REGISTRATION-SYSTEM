<?php
include("Database.php");

$database = new Database();
$conn = $database->connect();

$user_id = 1;

$sql = "SELECT registrations.registration_id, courses.course_code, courses.course_name, semesters.semester_name
        FROM registrations
        JOIN courses ON registrations.course_id = courses.course_id
        JOIN semesters ON courses.semester_id = semesters.semester_id
        WHERE registrations.user_id = '$user_id'";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Schedule</title>
</head>
<body>

<h1>My Registered Classes</h1>

<table border="1">
<tr>
    <th>Course Code</th>
    <th>Course Name</th>
    <th>Semester</th>
    <th>Action</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)) { ?>

<tr>
<td><?php echo $row['course_code']; ?></td>
<td><?php echo $row['course_name']; ?></td>
<td><?php echo $row['semester_name']; ?></td>
<td><a href="drop_course.php?registration_id=<?php echo $row['registration_id']; ?>">Drop</a></td>
</tr>

<?php } ?>

</table>

<br>
<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>