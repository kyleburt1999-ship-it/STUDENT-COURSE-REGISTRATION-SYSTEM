<?php
include("Database.php");

$database = new Database();
$conn = $database->connect();

$sql = "SELECT courses.course_id, courses.course_code, courses.course_name, semesters.semester_name
        FROM courses
        JOIN semesters
        ON courses.semester_id = semesters.semester_id";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Register for Classes</title>
</head>

<body>

<h1>Register for Classes</h1>

<table border="1">

<tr>
    <th>Course Code</th>
    <th>Course Name</th>
    <th>Semester</th>
    <th>Action</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)) { ?>

<tr>

<td><?php echo $row['course_code']; ?></td>

<td><?php echo $row['course_name']; ?></td>

<td><?php echo $row['semester_name']; ?></td>

<td>
<a href="add_course.php?course_id=<?php echo $row['course_id']; ?>">
Register
</a>
</td>

</tr>

<?php } ?>

</table>

<br>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>