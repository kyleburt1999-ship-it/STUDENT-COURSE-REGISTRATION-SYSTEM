<?php
class Database
{
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "course_registration";

    public function connect()
    {
        $connection = new mysqli($this->host, $this->username, $this->password, $this->database);

        if ($connection->connect_error) {
            die("Connection Failed: " . $connection->connect_error);
        }

        return $connection;
    }
}
?>