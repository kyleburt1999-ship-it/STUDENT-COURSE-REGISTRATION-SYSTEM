<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
</head>
<body>

<h1>Student Dashboard</h1>

<p>Welcome to the Online Course Registration System.</p>

<a href="register_course.php">Register for Classes</a><br><br>
<a href="my_schedule.php">View My Schedule</a><br><br>
<a href="logout.php">Logout</a>

</body>
</html>